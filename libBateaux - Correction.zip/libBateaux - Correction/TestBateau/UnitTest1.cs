using libBateaux;
namespace TestBateau
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]        
        public void TestVoyPlusAge()
        {
            Bateau b = new Bateau(10, 50, 259, 28, "Luce Isle");
            b.ajouteVoyageur(20, "Sionne", "Jacques");
            b.ajouteVoyageur(10, "Hinique", "Marthe");
            string attendu = "nom: Sionne\n prenom:Jacques\n age :20";
            string actuel = b.getLeVoyageurLePlusAge().ToString();
            Assert.AreEqual(attendu, actuel, "reussi");
        }
        [TestMethod]
        public void TestAjouterBateau()
        {
            //Aranger
            bool attendu = true;
            //Agir
            Flotte flotte = new Flotte();
            bool actuel = flotte.ajouterBateau("Luce Isle", 34,50, 345, 40);

            //Auditer
            Assert.AreEqual(attendu, actuel, "reussi");
        }
        [TestMethod]
        public void TestVoyageurString()
        {
            Voyageur v = new Voyageur(10, "Sionne", "Jacques");
            string attendu = "nom: Sionne\n prenom:Jacques\n age :10";
            string actuel = v.ToString();
            Assert.AreEqual(attendu, actuel, "reussi");
        }
        [TestMethod]
        public void TestBateauString()
        {
            Bateau b = new Bateau(10, 50, 259, 28, "Luce Isle");
            string attendu = "nom: Luce Isle\nlongueur: 50\nlargeur: 10\nnombre de passager maximum: 259\nvitesse maximum: 28";
            string actuel = b.ToString();
            Assert.AreEqual(attendu, actuel, "reussi");
        }
        [TestMethod]
        public void TestNomVoyageur()
        {
            Bateau b = new Bateau(10, 50, 259, 28, "Luce Isle");
            b.ajouteVoyageur(10, "Sionne", "Jacques");
            string attendu = "nom: Sionne\n prenom:Jacques\n age :10";
            string actuel = b.getLeVoyageur("Sionne").ToString();
            Assert.AreEqual(attendu, actuel, "reussi");
        }
        [TestMethod]
        public void TestNbVoy()
        {
            Bateau b = new Bateau(10, 50, 259, 28, "Luce Isle");
            b.ajouteVoyageur(10, "Sionne", "Jacques");
            int attendu = 1;
            int actuel = b.nbVoyageurs();
            Assert.AreEqual(attendu, actuel, "reussi");
        }


    }
}