﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace libBateaux
{
    internal class liaison
    {
        private DateTime dateliaison;
        string pointDep;
        string pointArrv;
        Bateau unBateau;
        public liaison(DateTime datel, string dep,string arr,Bateau b) { }
        public Bateau getBateau() {  return unBateau; }
    }
}
