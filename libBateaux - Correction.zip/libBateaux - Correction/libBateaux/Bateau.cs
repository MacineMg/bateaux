﻿namespace libBateaux
{
    public class Bateau
    {
        private int largeur;
        private int longueur;
        private int nbPassagersMax;
        private int vitesseMax;
        private string nom;
        private List<Voyageur> lesPassagers;
        public Bateau() {
            this.lesPassagers = new List<Voyageur>();
        }
        public Bateau(int largeur, int longueur, int nbPassagersMax, int vitesseMax, string nom)
        {
            this.largeur = largeur;
            this.longueur = longueur;
            this.nbPassagersMax = nbPassagersMax;
            this.vitesseMax = vitesseMax;
            this.nom = nom;
            this.lesPassagers = new List<Voyageur>();
        }

        public Voyageur getLeVoyageur(string nom) {
            List<Voyageur> unVoyageur = lesPassagers.FindAll(voyageur => voyageur.getNom() == nom);
            return unVoyageur[0]; }
        public int getNbPassagersMax() { return nbPassagersMax; }
        public void setVitesseMax(int vmax) { vitesseMax=vmax; }
        public int getVitesseMax() { return vitesseMax; }
        public string getNom() { return nom; }
        public int nbVoyageurs() {  return lesPassagers.Count; }
        public void ajouteVoyageur(int age, string nom, string prenom)
        {
            this.lesPassagers.Add(new Voyageur(age,nom,prenom));
        }
        public override string ToString()
        {
            return $"nom: {nom}\nlongueur: {longueur}\nlargeur: {largeur}\nnombre de passager maximum: {nbPassagersMax}\n" +
                $"vitesse maximum: {vitesseMax}";
        }
        public Voyageur getLeVoyageurLePlusAge()
        {
            Voyageur voyageur = null;
            voyageur = lesPassagers.Aggregate((max, next) => next.getAge() > max.getAge() ? next : max);
            return voyageur;

        }
        //{
        //    int max = 0;
        //    Voyageur voyageur = null;
        //    foreach (Voyageur v in lesPassagers)
        //    {
        //        if (v.getAge() >= max)
        //        {
        //            voyageur = v; max = v.getAge();
        //        }
        //    }
        //    return voyageur;
        //}




    }
}