﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace libBateaux
{
    public class Voyageur
    {
        private int age;
        private string nom;
        private string prenom;

        public Voyageur(int age, string nom, string prenom)
        {
            this.age = age;
            this.nom = nom;
            this.prenom = prenom;
        }
        public int getAge() { return age; }
        public string getNom() { return nom; }
        public string getPrenom() {  return prenom; }
        public override string ToString()
        {
            return $"nom: {nom}\n prenom:{prenom}\n age :{age}";
        }
    }
}
