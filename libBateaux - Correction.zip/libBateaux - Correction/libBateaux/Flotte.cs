﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace libBateaux
{
    public class Flotte
    {
        private List<Bateau> flotteList;

        public Flotte() { this.flotteList = new List<Bateau>(); }
        public void ajouterBateau(Bateau b) { }
        public void ajouterBateau(int largeur, int longueur, int nbPassagersMax, int vitesseMax, string nom)
        {
            flotteList.Add(new Bateau(largeur, longueur, nbPassagersMax, vitesseMax, nom));
        }
        public bool ajouterBateau(string nom, int longueur, int largeur,int nbPassagers, int vitesseMax) {
            try
            {
                flotteList.Add(new Bateau(largeur, longueur, nbPassagers, vitesseMax, nom));
            return true;
            }catch (Exception e) { return false; }
             }
        public Bateau getBateauPlusRapide() { 
            Bateau? b = null;
            int vmax = 0;
            foreach(Bateau unBateau in flotteList)
            {
                if (unBateau.getVitesseMax() > vmax)
                {
                    vmax=unBateau.getVitesseMax();
                    b = unBateau;
                }

            }
            return b; }
        public Bateau getLeBateau(int i) { Bateau? b = null; return b; }
        public Bateau getLeBateau(string nomBateau) { Bateau? b = null; return b; }

        public List<Bateau> getLesBateaux(int nbPassagers)
        {
            List<Bateau> flottes = flotteList.FindAll(bateau=>bateau.getNbPassagersMax()>=nbPassagers);
            return flottes;
        }
        public override string ToString()
        {
            string liste = "";
            foreach(Bateau bateau in flotteList)
            {
                liste += bateau.ToString()+'\n';
            }
            return liste;
        }
    }
}
